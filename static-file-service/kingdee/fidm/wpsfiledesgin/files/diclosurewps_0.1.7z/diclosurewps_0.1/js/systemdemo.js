
/**
 * web页面调用WPS加载项的方法入口
 *  * info参数结构
 * info:[
 *      {
 *       '方法名':'方法参数',需要执行的方法
 *     },
 *     ...
 *   ]
 * @param {*} info
 */
function dispatcher (info) {
  const funcs = info.funcs
  // 执行web页面传递的方法
  for (let index = 0; index < funcs.length; index++) {
    const func = funcs[index]
    for (const key in func) {
      func[key].isOA = true
      if (key === 'openPanel') { // OpenDoc 属于普通的打开文档的操作方式，文档落地操作
        openPanel(func[key]); // 进入打开文档处理函数
      } else if (key === 'createNewDoc') {
        createNewDoc(); 
      } else if (key === 'openDoc') {
        openDoc(func[key]); 
      }
    }
  }
  return { message: 'ok', app: wps.Application.Name }
}

function createNewDoc () {
  const wpsApp = getApp().WpsApplication()
  let doc = wpsApp.Documents.Add();
  return doc.Name;
}

function openDoc (data) {
  const wpsApp = getApp();

  const newDoc = wpsApp.Documents.Add();
  wpsApp.Selection.InsertBefore("文件正在打开，请耐心等待....");

  let url = data.url;
  var joiner = url.includes('?') ? '&' : '?';
  // 拼接 fileHeader = 1，表示后端返回的 header 中， content-disposition 需要修改为 attachment;filename=fileName.doc
  url = "".concat(url).concat(joiner, "fileHeader=1");
  const doc = wpsApp.Documents.OpenFromUrl(url);
  if (!doc) {
    //异常情况，新增文件显示，否则第一次打开无任何动静
    newDoc.Activate();
    newDoc.Select();
    wpsApp.Selection.Delete();
    wpsApp.Selection.InsertBefore("文件打开失败：" + url); 
  }else{
    newDoc.Close('wdDoNotSaveChanges', 'wdPromptUser');
  }
}


function openPanel (data) {
  // alert("data.Url:" + data.url)
  const wpsApp = getApp();
  const taskPane = wpsApp.CreateTaskPane(data.url)
  taskPane.DockPosition = window.Application ? window.Application.Enum.JSKsoEnum_msoCTPDockPositionLeft : window.WPS_Enum.msoCTPDockPositionLeft
  taskPane.Visible = data.visible;
  // taskPane.Width = data.width ? data.width : 300;
  // taskPane.MinWidth = data.minWidth ? data.minWidth : 300;
  // taskPane.MaxWidth = data.maxWidth ? data.maxWidth : 2000; 
  wpsApp.PluginStorage.setItem('pageDMPanel_id', taskPane.ID)

  if (data.openInitDoc) {
    //初始启动时资源需要全部下载，耗时较长，目前先加个初始界面处理
    let doc = wpsApp.Documents.Add();
    wpsApp.Selection.InsertBefore("文件正在打开，请耐心等待....");
    wpsApp.PluginStorage.setItem('pageDMPanel_initDoc', doc.Name)
  }
}

function getApp(){
  return window.Application || window.wps;
}
