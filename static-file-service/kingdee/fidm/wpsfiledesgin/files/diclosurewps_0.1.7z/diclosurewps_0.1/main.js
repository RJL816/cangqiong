//这个文件由index.html包含
document.write("<script language='javascript' src='js/util.js'></script>");
document.write("<script language='javascript' src='js/ribbon.js'></script>");
document.write("<script language='javascript' src='js/systemdemo.js'></script>");